const abandonedCartHandler = require('./eventsHandlers/abandonedCartHandler');
const createEmailDomainHandler = require('./eventsHandlers/createEmailDomainHandler');
const defaultHandler = require('./eventsHandlers/defaultHandler');
const deleteEmailGroupSubHandler = require('./eventsHandlers/deleteEmailGroupSubHandler');
const emailVerifiedHandler = require('./eventsHandlers/emailVerifiedHandler');
const giftRecipientSetHandler = require('./eventsHandlers/giftRecipientSetHandler');
const giftRedeemedHandler = require('./eventsHandlers/giftRedeemedHandler');
const giftSubscriptionPurchaseHandler = require('./eventsHandlers/giftSubscriptionPurchaseHandler');
const magicLinkSendHandler = require('./eventsHandlers/magicLinkSendHandler');
const orderConfirmationHandler = require('./eventsHandlers/orderConfirmationHandler');
const passwordResetHandler = require('./eventsHandlers/passwordResetHandler');
const passwordResetRequestHandler = require('./eventsHandlers/passwordResetRequestHandler');
const renewSubscriptionHandler = require('./eventsHandlers/renewSubscriptionHandler');
const startSubscriptionHandler = require('./eventsHandlers/startSubscriptionHandler');
const updateBillingAddressHandler = require('./eventsHandlers/updateBillingAddressHandler');
const updatePaymentMethodHandler = require('./eventsHandlers/updatePaymentMethodHandler');
const userSignInAddedHandler = require('./eventsHandlers/userSignInAddedHandler');
const userSignUpHandler = require('./eventsHandlers/userSignUpHandler');
const verifyEmailHandler = require('./eventsHandlers/verifyEmailHandler');

module.exports = {
  abandonedCartHandler,
  createEmailDomainHandler,
  defaultHandler,
  deleteEmailGroupSubHandler,
  emailVerifiedHandler,
  giftRecipientSetHandler,
  giftRedeemedHandler,
  giftSubscriptionPurchaseHandler,
  magicLinkSendHandler,
  orderConfirmationHandler,
  passwordResetHandler,
  passwordResetRequestHandler,
  renewSubscriptionHandler,
  startSubscriptionHandler,
  updateBillingAddressHandler,
  updatePaymentMethodHandler,
  userSignInAddedHandler,
  userSignUpHandler,
  verifyEmailHandler,
}