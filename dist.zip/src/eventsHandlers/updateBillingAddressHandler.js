const sendEmail = require("../sendEmail");

const updateBillingAddressHandler = async (event) => {

    const msg = {
      to: event?.body?.email,
      from: process.env.EMAIL_SENDER,
      // Please update templateId with correct value
      templateId: 'd-bfd97e501af24851b87d8ba73fc5407d',
      dynamic_template_data: {
        firstName: event?.body?.firstName,
        email: event?.body?.email
      }
    }

    await sendEmail(msg);
}
  
module.exports = updateBillingAddressHandler;