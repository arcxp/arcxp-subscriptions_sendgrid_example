const defaultHandler = (event) => {
    return { "status": "event did not match any handlers" }
  }
  
  module.exports = defaultHandler;